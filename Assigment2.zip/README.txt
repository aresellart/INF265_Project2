Running the code

To run the code is necessary to have the different datasets (corrupt and normal) in the same folder as the different ipynb files
for the code to be able to function properly.